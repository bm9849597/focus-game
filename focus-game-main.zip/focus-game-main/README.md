# focus-game
🎯 Focus Game is a fun and interactive web project built with HTML, CSS, and JavaScript. Test your reaction speed and concentration by clicking moving red dots before time runs out. Designed and developed by Abdullah Mustafa in 2025. Simple, fast, and addictive!
